import os, pickle
from typing import List
from pathlib import Path
from sentence_transformers import SentenceTransformer
import faiss
from .utils import extract_text_from_file, chunk_text, DATA_DIR

EMB_MODEL_NAME = "all-MiniLM-L6-v2"
INDEX_PATH = os.path.join(DATA_DIR, "faiss_index.bin")
META_PATH = os.path.join(DATA_DIR, "metadatas.pkl")

def ingest_documents(file_paths: List[str], chunk_size=1200, chunk_overlap=200):
    os.makedirs(DATA_DIR, exist_ok=True)
    model = SentenceTransformer(EMB_MODEL_NAME)
    texts = []
    metadatas = []
    for path in file_paths:
        text = extract_text_from_file(path)
        chunks = chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        for i, c in enumerate(chunks):
            texts.append(c)
            metadatas.append({"source": Path(path).name, "chunk_id": i})
    # compute embeddings
    embeddings = model.encode(texts, show_progress_bar=True, convert_to_numpy=True)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    # save index and metadatas
    faiss.write_index(index, INDEX_PATH)
    with open(META_PATH, "wb") as f:
        pickle.dump({"texts": texts, "metadatas": metadatas}, f)
    return {"index_path": INDEX_PATH, "meta_path": META_PATH, "emb_model": EMB_MODEL_NAME}

def load_vectorstore():
    if not os.path.exists(INDEX_PATH) or not os.path.exists(META_PATH):
        return None
    model = SentenceTransformer(EMB_MODEL_NAME)
    index = faiss.read_index(INDEX_PATH)
    with open(META_PATH, "rb") as f:
        data = pickle.load(f)
    return {"index": index, "texts": data["texts"], "metadatas": data["metadatas"], "emb_model": EMB_MODEL_NAME}

def save_vectorstore(vs):
    # vs is the dict returned by ingest_documents; files are already saved
    return True
