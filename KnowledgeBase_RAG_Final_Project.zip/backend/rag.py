import os
from typing import List, Tuple
from .ingest import load_vectorstore, EMB_MODEL_NAME
from .utils import load_openai_api_key
from sentence_transformers import SentenceTransformer
import openai

SYSTEM_PROMPT = "You are a helpful assistant. Use the provided context snippets to answer the user's question. Quote or mention sources where useful."

def answer_query(query: str, top_k: int = 4) -> Tuple[str, List[dict]]:
    vs = load_vectorstore()
    if vs is None:
        raise ValueError("Vectorstore not found. Please ingest documents first.")
    model = SentenceTransformer(EMB_MODEL_NAME)
    q_emb = model.encode([query], convert_to_numpy=True)
    index = vs["index"]
    D, I = index.search(q_emb, top_k)
    texts = vs["texts"]
    metadatas = vs["metadatas"]
    retrieved = []
    context_parts = []
    for idx in I[0]:
        retrieved.append({"text": texts[idx], "source": metadatas[idx]["source"]})
        context_parts.append(texts[idx])
    # prepare prompt for OpenAI
    context_combined = "\n\n---\n\n".join(context_parts)
    user_prompt = f"""Answer the question using ONLY the context below. If the answer is not contained, say 'I don't know' briefly.

Context:
{context_combined}

Question:
{query}

Give a concise answer and list the sources (filename) you used."""
    # call OpenAI
    openai_api_key = load_openai_api_key()
    if not openai_api_key:
        # fallback: return extracted chunks only
        answer = "OpenAI API key not found. Returning retrieved chunks as fallback.\n\n" + "\n\n---\n\n".join([r["text"][:1000] for r in retrieved])
        return answer, retrieved
    openai.api_key = openai_api_key
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role":"system","content":SYSTEM_PROMPT},{"role":"user","content":user_prompt}],
        max_tokens=512,
        temperature=0.0,
    )
    answer = resp["choices"][0]["message"]["content"].strip()
    return answer, retrieved
